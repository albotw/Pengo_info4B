package com.generic.core;

public interface Orientation {
    String getOrientation();

    void setOrientation(char direction);
}
