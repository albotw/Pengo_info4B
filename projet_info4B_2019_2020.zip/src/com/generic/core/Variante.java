package com.generic.core;

public interface Variante {
    void setVariante(String variante);
    String getVariante();
}
